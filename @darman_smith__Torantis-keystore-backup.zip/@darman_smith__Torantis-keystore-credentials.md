# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: f523e48696f2b67b37c1032aec90b240
- Android key alias: 114bef954b69ae21596c30cecafb6774
- Android key password: c432e6d53692f493310ea71b902af177
      